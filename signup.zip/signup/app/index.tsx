import { Text, View } from "react-native";
import Signup from './components/Signup';
export default function Index() {
  return (
    <View style={{flex:1}}>
      <Signup/>
     </View>
  );
}
