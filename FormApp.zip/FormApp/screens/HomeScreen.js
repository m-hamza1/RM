import React, { useState } from 'react';
import { View, StyleSheet, Text, ScrollView } from 'react-native';
import FormInput from '../components/FormInput';
import FormButtons from '../components/FormButtons';
import SubmittedData from '../components/SubmittedData';

export default function HomeScreen() {
  const [form, setForm] = useState({ name: '', email: '', phone: '' });
  const [errors, setErrors] = useState({});
  const [submittedData, setSubmittedData] = useState(null);

  const validate = () => {
    let valid = true;
    let newErrors = {};

    if (!form.name.trim()) {
      newErrors.name = 'Name is required';
      valid = false;
    }

    if (!form.email.trim()) {
      newErrors.email = 'Email is required';
      valid = false;
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'Invalid email format';
      valid = false;
    }

    if (!form.phone.trim()) {
      newErrors.phone = 'Phone is required';
      valid = false;
    } else if (!/^\d{10}$/.test(form.phone)) {
      newErrors.phone = 'Phone must be 10 digits';
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleChange = (field, value) => {
    setForm({ ...form, [field]: value });
  };

  const handleSubmit = () => {
    if (validate()) {
      setSubmittedData(form);
    }
  };

  const handleReset = () => {
    setForm({ name: '', email: '', phone: '' });
    setErrors({});
    setSubmittedData(null);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>React Native Form</Text>

      <FormInput
        label="Name"
        value={form.name}
        error={errors.name}
        onChangeText={(text) => handleChange('name', text)}
      />
      <FormInput
        label="Email"
        value={form.email}
        keyboardType="email-address"
        error={errors.email}
        onChangeText={(text) => handleChange('email', text)}
      />
      <FormInput
        label="Phone"
        value={form.phone}
        keyboardType="phone-pad"
        error={errors.phone}
        onChangeText={(text) => handleChange('phone', text)}
      />

      <FormButtons onSubmit={handleSubmit} onReset={handleReset} />

      {submittedData && <SubmittedData data={submittedData} />}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flexGrow: 1,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    alignSelf: 'center',
  },
});