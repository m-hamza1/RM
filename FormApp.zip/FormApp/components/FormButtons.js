import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

const FormButtons = ({ onSubmit, onReset }) => {
  return (
    <View style={styles.buttonContainer}>
      <Button title="Submit" onPress={onSubmit} />
      <Button title="Reset" onPress={onReset} color="gray" />
    </View>
  );
};

const styles = StyleSheet.create({
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 15,
  },
});

export default FormButtons;