import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const SubmittedData = ({ data }) => {
  return (
    <View style={styles.result}>
      <Text style={styles.title}>Submitted Data:</Text>
      <Text>Name: {data.name}</Text>
      <Text>Email: {data.email}</Text>
      <Text>Phone: {data.phone}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  result: {
    padding: 15,
    backgroundColor: '#e8f0fe',
    borderRadius: 10,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 10,
  },
});

export default SubmittedData;